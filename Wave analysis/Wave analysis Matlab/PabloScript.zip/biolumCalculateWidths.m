function Analyzed = biolumCalculateWidths(Analyzed, max_nr_cycles)

nr_cells = size(Analyzed.PeakTimes, 1);

width = zeros(nr_cells, max_nr_cycles);
period = zeros(nr_cells, max_nr_cycles);

for i=1:nr_cells
    for j = 1:max_nr_cycles-1
        if Analyzed.HalfmaxDownTimes(i,j) > Analyzed.HalfmaxUpTimes(i,j) && Analyzed.HalfmaxUpTimes(i,j) > 0
            width(i,j) = Analyzed.HalfmaxDownTimes(i,j) - Analyzed.HalfmaxUpTimes(i,j);
        elseif Analyzed.HalfmaxDownTimes(i,j+1) > Analyzed.HalfmaxUpTimes(i,j) && Analyzed.HalfmaxUpTimes(i,j) > 0
            width(i,j) = Analyzed.HalfmaxDownTimes(i,j+1) - Analyzed.HalfmaxUpTimes(i,j);
        end
        if Analyzed.HalfmaxUpTimes(i,j+1) > Analyzed.HalfmaxUpTimes(i,j) && Analyzed.HalfmaxUpTimes(i,j) > 0
            period(i,j) = Analyzed.HalfmaxUpTimes(i,j+1) - Analyzed.HalfmaxUpTimes(i,j);
        end
    end
    j = 1;
    while (width(i,j) > 0)
        j=j+1;
    end
    av_width = mean(width(i,1:j-1));
    width(i,max_nr_cycles+1) = av_width;
    j = 1;
    while (period(i,j) > 0)
        j=j+1;
    end
    av_period = mean(period(i,1:j-1));
    period(i,max_nr_cycles+1) = av_period;
end

Analyzed.WidthHalfmax = width;
Analyzed.PeriodHalfmax = period;