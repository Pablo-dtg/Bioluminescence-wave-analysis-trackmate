tim = smoothdata(:,1);
val = smoothdata(:,2);
plotThem(peak_phase(1,:),tim,val)
plotThem(trough_phase(1,:),tim,val)