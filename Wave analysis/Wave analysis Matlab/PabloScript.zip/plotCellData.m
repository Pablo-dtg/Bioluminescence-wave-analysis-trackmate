function plotCellData(Analyzed, cellnr)

signal = rmmissing(Analyzed.Smooth(:,cellnr));
tim = rmmissing(Analyzed.Time(:,cellnr));

MINProm     = std(signal)*0.1; % height of peak (default =0.1)

[pkvals,pklocs,pkwidths,~] = findpeaks(signal,'MinPeakProminence',MINProm,'MinPeakDistance',12*Analyzed.factor);

signal_inverted = -signal;
[trvals,trlocs,trwidths,~] = findpeaks(signal_inverted,'MinPeakProminence',MINProm,'MinPeakDistance',12*Analyzed.factor);

figure
title('Peaks and Troughs Signal')
%     end
%     if(i<10)
%         subplot(3,3,i);
hold on
plot(tim,signal)
plot(tim(pklocs),signal(pklocs),'rv','MarkerFaceColor','r')
plot(tim(trlocs),signal(trlocs),'rs','MarkerFaceColor','b')
% axis([0 1850 -1.1 1.1])
grid on
legend('Signal','Peaks','Troughs')
xlabel('Time')
ylabel('Bioluminescence')

