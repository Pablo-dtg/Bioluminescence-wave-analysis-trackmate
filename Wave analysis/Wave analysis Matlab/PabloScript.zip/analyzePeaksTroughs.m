function Analyzed = analyzePeaksTroughs(smoothsignal, t, factor, max_nr_peaks)

for i=1:size(smoothsignal,2)
    
    signal = rmmissing(smoothsignal(:,i));
    tim = rmmissing(t(:,i));
    
    MINProm     = std(signal)*0.1; % height of peak (default =0.1)

    [pkvals,pklocs,pkwidths,~] = findpeaks(signal,'MinPeakProminence',MINProm,'MinPeakDistance',12*factor);
    
    signal_inverted = -signal;
    [trvals,trlocs,trwidths,~] = findpeaks(signal_inverted,'MinPeakProminence',MINProm,'MinPeakDistance',12*factor);

% There was one experiment where the mean signal gave strange results
% The experiment number was K+ 21mM export_240909_1
% First five hours of data were discarded
%     if do==1
%         trvals = [trvals(1); trvals(3:end)];
%         trlocs = [trlocs(1); trlocs(3:end)];
%         trwidths = [trwidths(1); trwidths(3:end)];
%     end

% There was one experiment where there were two troughs between two peaks
% The experment number was K+ 11mM export_240429_1, cell 51
% Another experiment was K+ 11mM export_240429_2, cell 58
% Another experiment was K+ 15mM export_240805_1_bgc, cell 15
% Another experiment was K+ 15mM export_240805_2_bgc, cell 1 and cell 39
% Check was done and second trough was discarded
% if (i==58)
%     nr_peaks = size(pklocs,1);
%     nr_troughs = size(trlocs,1);
%     if (pklocs(1) > trlocs(1))
%         pnr = 1;
%         while pnr < nr_peaks
%             if (pklocs(pnr) > trlocs(pnr+1))
%                 % Error: remove trlocs(pnr)
%                 tnr = pnr+1;
%                 while tnr<nr_troughs
%                     trlocs(tnr) = trlocs(tnr+1);
%                     trvals(tnr) = trvals(tnr+1);
%                     trwidths(tnr) = trwidths(tnr+1);
%                     tnr=tnr+1;
%                 end
%                 trlocs(tnr)=[];
%                 trvals(tnr)=[];
%                 trwidths(tnr)=[];
%             else
%                 pnr = pnr+1;
%             end
%         end
%     end
% end
% Another experiment was K+ 15mM export_240805_2_bgc, cell 1 and cell 39
% if (i==1)
%     nr_peaks = size(pklocs,1);
%     nr_troughs = size(trlocs,1);
%     if (pklocs(2) > trlocs(1))
%         pnr = 2;
%         while pnr < nr_peaks
%             if (pklocs(pnr) > trlocs(pnr))
%                 % Error: remove trlocs(pnr)
%                 tnr = pnr;
%                 while tnr<nr_troughs
%                     trlocs(tnr) = trlocs(tnr+1);
%                     trvals(tnr) = trvals(tnr+1);
%                     trwidths(tnr) = trwidths(tnr+1);
%                     tnr=tnr+1;
%                 end
%                 trlocs(tnr)=[];
%                 trvals(tnr)=[];
%                 trwidths(tnr)=[];
%             else
%                 pnr = pnr+1;
%             end
%         end
%     end
% end
% if (i==39)
%     nr_peaks = size(pklocs,1);
%     nr_troughs = size(trlocs,1);
%     if (pklocs(1) > trlocs(1))
%         pnr = 1;
%         while pnr < nr_peaks
%             if (pklocs(pnr) > trlocs(pnr+1))
%                 % Error: remove trlocs(pnr)
%                 tnr = pnr;
%                 while tnr<nr_troughs
%                     trlocs(tnr) = trlocs(tnr+1);
%                     trvals(tnr) = trvals(tnr+1);
%                     trwidths(tnr) = trwidths(tnr+1);
%                     tnr=tnr+1;
%                 end
%                 trlocs(tnr)=[];
%                 trvals(tnr)=[];
%                 trwidths(tnr)=[];
%                 pnr = nr_peaks;
%             else
%                 pnr = pnr+1;
%             end
%         end
%     end
% end
                
    
    if(i==1)
        figure
        title('Peaks and Troughs Signal')
%     end
%     if(i<10)
%         subplot(3,3,i);
        hold on
        plot(tim,signal)
        plot(tim(pklocs),signal(pklocs),'rv','MarkerFaceColor','r')
        plot(tim(trlocs),signal(trlocs),'rs','MarkerFaceColor','b')
        % axis([0 1850 -1.1 1.1])
        grid on
        legend('Signal','Peaks','Troughs')
        xlabel('Time')
        ylabel('Bioluminescence')
    end
    
    % Peaks and Troughs need to have a constant length, so they are
    % filled with '0'.
    pktim = tim(pklocs);
    trtim = tim(trlocs);
    periods = diff(pklocs)/factor; % Period based on peaktimes
    if size(pkvals,1)>max_nr_peaks
        pkvals = pkvals(1:max_nr_peaks);
        pklocs = pklocs(1:max_nr_peaks);
        pktim = pktim(1:max_nr_peaks);
        pkwidths = pkwidths(1:max_nr_peaks);
        periods = periods(1:max_nr_peaks-1);
    else
        while(size(pkvals,1)<max_nr_peaks)
            pkvals = [pkvals; 0];
            pklocs = [pklocs; 0];
            pktim = [pktim; 0];
            pkwidths = [pkwidths; 0];
            periods = [periods; 0];
        end
    end
    if size(trvals,1)>max_nr_peaks
        trvals = trvals(1:max_nr_peaks);
        trlocs = trlocs(1:max_nr_peaks);
        trtim = trtim(1:max_nr_peaks);
        trwidths = trwidths(1:max_nr_peaks);
    else
        while(size(trvals,1)<max_nr_peaks)
            trvals = [trvals; 0];
            trlocs = [trlocs; 0];
            trtim = [trtim; 0];
            trwidths = [trwidths; 0];
        end
    end
    
    Analyzed.PeakVals(i,:) = pkvals';
    Analyzed.Peaks(i,:) = pklocs';
    Analyzed.PeakTimes(i,:) = pktim';
    Analyzed.PeakWidths(i,:) = pkwidths';
    
    Analyzed.TroughVals(i,:) = -trvals';
    Analyzed.Troughs(i,:) = trlocs';
    Analyzed.TroughTimes(i,:) = trtim';
    Analyzed.TroughWidths(i,:) = trwidths';
    Analyzed.PeriodPeaks(i,:) = periods;
    
    % Find halfmax values
    halfmaxup = [];
    halfmaxdown = [];
    halfmaxuptimes = [];
    halfmaxdowntimes = [];
    [halfmaxup, halfmaxdown] = biolum_FindHalfmax(Analyzed, signal,i, max_nr_peaks);
    halfmaxuptimes = tim(halfmaxup);
    halfmaxdowntimes = tim(halfmaxdown);
    if size(halfmaxup,1)>max_nr_peaks
        halfmaxup = halfmaxup(1:max_nr_peaks);
        halfmaxuptimes = halfmaxuptimes(1:max_nr_peaks);
    else
        while(size(halfmaxup,1)<max_nr_peaks)
            halfmaxup = [halfmaxup; 0];
            halfmaxuptimes = [halfmaxuptimes; 0];
        end
    end
    if size(halfmaxdown,1)>max_nr_peaks
        halfmaxdown = halfmaxdown(1:max_nr_peaks);
        halfmaxdowntimes = halfmaxdowntimes(1:max_nr_peaks);
    else
        while(size(halfmaxdown,1)<max_nr_peaks)
            halfmaxdown = [halfmaxdown; 0];
            halfmaxdowntimes = [halfmaxdowntimes; 0];
        end
    end
    Analyzed.HalfmaxUp(i,:) = halfmaxup;
    Analyzed.HalfmaxUpTimes(i,:) = halfmaxuptimes;
    Analyzed.HalfmaxDown(i,:) = halfmaxdown;
    Analyzed.HalfmaxDownTimes(i,:) = halfmaxdowntimes;

end
