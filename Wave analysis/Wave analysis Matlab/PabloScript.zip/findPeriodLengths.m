function [perlen, lenptot, lenttop] = findPeriodLengths(peak_phase, trough_phase)

perlen=zeros(1,10); %Period length
lenptot=zeros(1,10); %Length peak to trough
lenttop=zeros(1,10); %Length trough to peak

for i=1:9
    if peak_phase(1) < trough_phase(1)
        if peak_phase(i+1) ~= 0 && trough_phase(i) ~= 0
            lenptot(i) = trough_phase(i)-peak_phase(i);
            lenttop(i) = peak_phase(i+1)-trough_phase(i);
            perlen(i) = peak_phase(i+1)-peak_phase(i);
        end
    else
        if trough_phase(i+1) ~=0 && peak_phase(i+1) ~= 0
            lenptot(i) = trough_phase(i+1)-peak_phase(i);
            lenttop(i) = peak_phase(i)-trough_phase(i);
            perlen(i) = peak_phase(i+1)-peak_phase(i);
        end
    end
end
