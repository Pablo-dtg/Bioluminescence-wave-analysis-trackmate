function z = smoothmatsimpleHT(y, beta,d,w)
% Differential smoother for matrix
% P. Eilers
% Adjusted and Commented by H.T. van der Leest
% Adjusted to account for resizing the data by J.H.T.Rohling

%
y = y'; %Rotate Matrix
% If w is given, the smoothed signal will be resized compared to the
% original data.
if nargin < 4
    w = ones(size(y'))'; %Create matrix of ones as weights
end
if nargin < 3
    d = 2; %set differential to 1st or 2nd etc. order
end
%needed to scale the smoothing parameter, not used since a single digit is
%given for beta and weights are always 1
% beta2   = repmat(beta-min(beta),1,size(y,1))';
% w       = beta2 .* w;
% beta    = max(beta);

if ~any(size(y)==0)
    spparms('autommd', 0);
    m = size(y,1);
    E = speye(m);
    D = diff(E,d);
    Q = beta * (D' * D);
    W = spdiags(w, 0, m, m);
    z = (W + Q) \ (W * y);
end
z=z';