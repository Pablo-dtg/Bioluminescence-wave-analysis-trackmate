function plotThem(pt, tim, val)

%Plots all troughs or all peaks
figure;
plot(tim,val);
figure;
for i=1:10
    if pt(i)~=0
        index = find(tim==pt(i));
        line_idx1 = index-200;
        if line_idx1 < 0
            line_idx1=1;
        end
        line_idx2 = index+200;
        if line_idx2>size(tim,1)
            line_idx2 = size(tim,1);
        end
        subplot(2,5,i)
        plot(tim(index), val(index), '*');
        hold on
        plot(tim(line_idx1:line_idx2), val(line_idx1:line_idx2))
        hold off
    end
end