function Analyzed = biolumFindPeaksTroughs(Analyzed, Signal, max_nr_peaks)
% For each time series, find the peaks and the troughs
% The Peaks and Troughs can be different in number for different signals.
% The the Peaks and Troughs vectors in the matrices have equal length, so
% the vectors are filled with '0' when no Peaks or Troughs bins are
% present. 
% Example: Peaks = [100, 300, 500, 0, 0, 0, 0, ... 0], has three peaks.

for i = 1:size(Signal,2)
    bin_nr = 1;   % Nr of bin where we are in the time series
    Peaks = [];   % Peak bins in this time series
    Troughs = []; % Trough bins in this time series
    time_series = Signal(:,i);
    while(bin_nr < size(time_series,1))
        if biolum_risingEdge(time_series, bin_nr)
            % On a rising edge: find peak
            bin = biolum_FindPeak(time_series,bin_nr,1);
            if bin > 0
                Peaks = [Peaks, bin];
                bin_nr = bin;
            else
                bin_nr = size(time_series,1);
            end
        elseif biolum_fallingEdge(time_series, bin_nr)
            % On a falling edge: find trough
            bin = biolum_FindTrough(time_series,bin_nr,1);
            if bin > 0
                Troughs = [Troughs, bin];
                bin_nr = bin;
            else
                bin_nr = size(time_series,1);
            end
        else
            % Somewhere near a trough or a peak
            bin_nr = bin_nr+1;
        end
    end
    % Peaks and Troughs need to have a constant length, so they are
    % filled with '0'.
    if size(Peaks,2)>max_nr_peaks
        Peaks = Peaks(1:max_nr_peaks);
    else
        while(size(Peaks,2)<max_nr_peaks)
            Peaks = [Peaks, 0];
        end
    end
    if size(Troughs,2)>max_nr_peaks
        Troughs = Troughs(1:max_nr_peaks);
    else
        while(size(Troughs,2)<max_nr_peaks)
            Troughs = [Troughs, 0];
        end
    end
    Analyzed.Peaks(i,:) = Peaks;
    Analyzed.Troughs(i,:) = Troughs;
end