function isTrue = biolum_fallingEdge(Smooth, bin_nr)
isTrue = 1;
for i = 1:5
    if bin_nr < size(Smooth,1)-1
        if Smooth(bin_nr+1) < Smooth(bin_nr)
            bin_nr = bin_nr+1;
            i = i+1;
        else
            isTrue = 0;
        end
    else
        i = 5;
    end
end