function bin = biolum_FindBin(Signal, startbin, val, up)
% Find bin in Signal, strarting from 'startbin', that is closest to
% 'val'. Up shows if we are on a rising (up = 1) or falling slope (up=0)
% Works only with smoothed data!
finished = 0;
i = startbin;
while(finished == 0)
    if i > size(Signal,1)
        % bin is outside boundaries of Signal (end of Signal vector is
        % reached). Stop searching and return bin = 0;
        bin = 0;
        finished = 1;
        disp('Error in biolum_FindBin: bin is outside scope');
    else
        if up ==1;
            % On rising slope, as soon as Signal is bigger than 'val', we
            % have found the bin
            if Signal(i) > val
                if (Signal(i-1) - val) > (Signal(i) - val)
                    % Difference between Signal(i) and 'val' is smaller
                    % than difference between Signal(i-1) and 'val' so bin
                    % 'i' is the closest bin.
                    bin = i;
                else
                    % Difference between Signal(i-1) and 'val' is smaller
                    % than difference between Signal(i) and 'val' so bin
                    % 'i-1' is the closest bin.
                   bin = i-1;
                end
                finished = 1;
            else
                i = i+1;
            end
        else
            % On falling slope, as soon as Signal is smaller than 'val', we
            % have found the bin
            if Signal(i) < val
                if (Signal(i-1) - val) > (Signal(i) - val)
                    % Difference between Signal(i) and 'val' is smaller
                    % than difference between Signal(i-1) and 'val' so bin
                    % 'i' is the closest bin.
                    bin = i;
                else
                    % Difference between Signal(i-1) and 'val' is smaller
                    % than difference between Signal(i) and 'val' so bin
                    % 'i-1' is the closest bin.
                    bin = i-1;
                end
                finished = 1;
            else
                i = i+1;
            end
        end
    end
end
        