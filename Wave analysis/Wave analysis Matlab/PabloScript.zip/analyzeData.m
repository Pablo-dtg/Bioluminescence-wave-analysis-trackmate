smoothdata=K21mMS1;
rawdata=K1mM;
% smoothdata=K3mMto21mMCT5S1;
% smoothdata=K3mMto21mMCT5S1;
% smoothdata=K3mMto21mMCT5S1;

nr_cells = size(smoothdata,2)/2;

% Time from 0 to180 hours
% Time of first peak is between 20-30 hours
% Time of second peak is between 50-60 hours
% Time of third peak is between 75-85 hours
% Time of fourth peak is between 100-110 hours
% Time of fifth peak is between 125-140 hours
% Time of sixth peak is between 145-170 hours
% Time of first trough is between 30-50 hours
% ...

peaks=zeros(nr_cells,10);
troughs=zeros(nr_cells,10);
peak_phase=zeros(nr_cells,10);
trough_phase=zeros(nr_cells,10);
length_peak_to_trough=zeros(nr_cells,10);
length_trough_to_peak=zeros(nr_cells,10);
length_period=zeros(nr_cells,10);

for i=1:nr_cells
    do_run=1;
    tim = smoothdata(:,(i*2)-1);
    if isempty(tim)
        disp('No time data for cell ');
        disp(nr_cells);
        do_run = 0;
    end
    val = smoothdata(:,i*2);
    if isempty(val)
        disp('No value data for cell ');
        disp(nr_cells);
        do_run = 0;
    end
    tim = rmmissing(tim);
    val = rmmissing(val);
    tim2 =[tim(1):1/60:tim(end)+1]';
    factor = 60;
    t=1;
    [smooth, norm, detrended, smoothfactor] = biolumSmoothData(val, factor, t, tim2);
    if (do_run)
%         detrend_trace = detrendTrace(val);
%         val = val-mean_trace;
%         if (i==1)
%             plot(tim,val);
%         end
        [peaks(i,:), troughs(i,:), peak_phase(i,:), trough_phase(i,:)] = findPeaksTroughs(tim2,smooth);
%        [peaks(i,:), troughs(i,:), peak_phase(i,:), trough_phase(i,:)] = findPeaksTroughs(tim,val);
        [length_period(i,:), length_peak_to_trough(i,:), length_trough_to_peak(i,:)] = findPeriodLengths(peak_phase(i,:), trough_phase(i,:));
    end
end

checkPeaks;
%     tim = smoothdata(:,1);
%     val = smoothdata(:,2);
%     [peaks, troughs, peak_phase, trough_phase] = findPeaksTroughs(tim,val);