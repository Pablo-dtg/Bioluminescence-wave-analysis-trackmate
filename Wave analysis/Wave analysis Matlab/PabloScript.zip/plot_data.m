figure
plot(K21mM.x, K21mM.y)
hold on
plot(K21mMS1.x, K21mMS1.y,'r')
hold off

figure
for i=1:9
    if i==1
        titel='Cell 0';
        x=K21mM.x;
        y=K21mM.y;
        xs=K21mMS1.x;
        ys=K21mMS1.y;
    elseif i==2
        titel='Cell 1';
        x=K21mM.x1;
        y=K21mM.y1;
        xs=K21mMS1.x1;
        ys=K21mMS1.y1;
    elseif i==3
        titel='Cell 2';
        x=K21mM.x2;
        y=K21mM.y2;
        xs=K21mMS1.x2;
        ys=K21mMS1.y2;
    elseif i==4
        titel='Cell 120';
        x=K21mM.x120;
        y=K21mM.y120;
        xs=K21mMS1.x120;
        ys=K21mMS1.y120;
    elseif i==5
        titel='Cell 121';
        x=K21mM.x121;
        y=K21mM.y121;
        xs=K21mMS1.x121;
        ys=K21mMS1.y121;
    elseif i==6
        titel='Cell 122';
        x=K21mM.x122;
        y=K21mM.y122;
        xs=K21mMS1.x122;
        ys=K21mMS1.y122;
    elseif i==7
        titel='Cell 191';
        x=K21mM.x191;
        y=K21mM.y191;
        xs=K21mMS1.x191;
        ys=K21mMS1.y191;
    elseif i==8
        titel='Cell 192';
        x=K21mM.x192;
        y=K21mM.y192;
        xs=K21mMS1.x192;
        ys=K21mMS1.y192;
    else
        titel='Cell 193';
        x=K21mM.x193;
        y=K21mM.y193;
        xs=K21mMS1.x193;
        ys=K21mMS1.y193;
    end
    subplot(3,3,i)
    plot(x, y)
    hold on
    plot(xs, ys,'r')
    hold off
    %title(titel);
    xlim([0,180]);
end

