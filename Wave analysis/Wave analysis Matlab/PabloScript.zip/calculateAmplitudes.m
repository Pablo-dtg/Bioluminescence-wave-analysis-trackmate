function Analyzed = calculateAmplitudes(Analyzed, max_nr_cycles)

nr_cells = size(Analyzed.PeakTimes, 1);

amplitude_p2t = zeros(nr_cells, max_nr_cycles);
amplitude_t2p = zeros(nr_cells, max_nr_cycles);

idx_a_p2t = 1;
idx_a_t2p = 1;

for i=1:nr_cells
   if Analyzed.PeakTimes(i,1)<Analyzed.TroughTimes(i,1)
        j=1;
        while Analyzed.PeakTimes(i,j)~=0
            amplitude_p2t(i,idx_a_p2t)=Analyzed.PeakVals(i,j)-Analyzed.TroughVals(i,j);
            if (Analyzed.PeakTimes(i,j+1)~=0)
                amplitude_t2p(i,idx_a_t2p)=abs(Analyzed.TroughVals(i,j)-Analyzed.PeakVals(i,j+1));
            end
            idx_a_p2t = idx_a_p2t+1;
            idx_a_t2p = idx_a_t2p+1;
            j=j+1;
        end
    else
        j=1;
        while Analyzed.TroughTimes(i,j)~=0
            amplitude_t2p(i,idx_a_p2t)=abs(Analyzed.TroughVals(i,j)-Analyzed.PeakVals(i,j));
            if (Analyzed.TroughTimes(i,j+1)~=0)
                amplitude_p2t(i,idx_a_t2p)=abs(Analyzed.PeakVals(i,j)-Analyzed.TroughVals(i,j+1));
            end
            idx_a_p2t = idx_a_p2t+1;
            idx_a_t2p = idx_a_t2p+1;
            j=j+1;
        end
    end
    idx_a_p2t = 1;
    idx_a_t2p = 1;
    
    j = 1;
    while (amplitude_p2t(i,j) > 0)
        j=j+1;
    end
    av_amplitude_p2t = mean(amplitude_p2t(i,1:j-1));
    amplitude_p2t(i,max_nr_cycles+1) = av_amplitude_p2t;
    j = 1;
    while (amplitude_t2p(i,j) > 0)
        j=j+1;
    end
    av_amplitude_t2p = mean(amplitude_t2p(i,1:j-1));
    amplitude_t2p(i,max_nr_cycles+1) = av_amplitude_t2p;
end
Analyzed.P2TAmplitude = amplitude_p2t;
Analyzed.T2PAmplitude = amplitude_t2p;