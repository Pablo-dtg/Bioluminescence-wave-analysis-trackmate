function Analyzed = createCellData(rawdata)
% smoothdata=K1mMS1;
% rawdata=K1mM;
% smoothdata=K3mMto21mMCT5S1;
% smoothdata=K3mMto21mMCT5S1;
% smoothdata=K3mMto21mMCT5S1;

nr_cells = size(rawdata,2)/2;
factor = 60;
max_nr_peaks = 15;

for i=1:nr_cells
    timecalc(:,i) = rawdata(:,(i*2)-1);
end

maxtime_h = max(max(timecalc));
mintime_h = min(min(timecalc));
maxtime_m = (maxtime_h+1-mintime_h)*60;
clear timecalc;

smoothval = NaN(maxtime_m,nr_cells);
smoothtime = NaN(maxtime_m,nr_cells);
norm = NaN(maxtime_m,nr_cells);
detrended = NaN(maxtime_m,nr_cells);

% Find all 'good' waves:
%  - Minimal 3 pekas
%  - Distance between the peaks maximally 28 hours
%  - Distance between the peaks at least 20 hours
j=1;
t=1;
goodwaves = [];
badwaves = [];
for i=1:nr_cells
    tim_r = rawdata(:,(i*2)-1); %rawtime(:,i);
    val_r = rawdata(:,i*2); %rawval(:,i);
    tim = rmmissing(tim_r);
    val = rmmissing(val_r);
    tim2 =[tim(1):1/60:tim(end)+1]';

    [good_wave, smooth, norms, detrendeds, smoothfactor] = biolumSmoothData(val, factor, t, tim2);
    if (good_wave)
        smoothval(1:size(smooth,1),j)=smooth;
        norm(1:size(norms,1),j)=norms;
        detrended(1:size(detrendeds,1),j)=detrendeds;
        smoothtime(1:size(smooth,1),j)= tim2(1:end-1);
        rawtime(:,j) = tim_r;
        rawval(:,j) = val_r;
        j=j+1;
        goodwaves = [goodwaves, i];
    else
        badwaves = [badwaves, i];
    end
end
bads = i-(j-1);
goods = j-1;
disp(['There were ' num2str(bads) ' bad waves']);
disp(['There were ' num2str(goods) ' good waves']);
smoothval = smoothval(:,[1:j-1]);
norm = norm(:,[1:j-1]);
detrended = detrended(:,[1:j-1]);
smoothtime = smoothtime(:,[1:j-1]);

% Put all good waves in Analyzed structure
Analyzed = analyzePeaksTroughs(smoothval, smoothtime, factor, max_nr_peaks);
Analyzed.Smooth = smoothval;
Analyzed.Raw = rawval;
Analyzed.Detrended = detrended;
Analyzed.Trend = norm;
Analyzed.Time = smoothtime;
Analyzed.TimeRaw = rawtime;

% Calculate widths from halfmax
Analyzed = biolumCalculateWidths(Analyzed, max_nr_peaks);
% Calculate amplitudes
Analyzed = calculateAmplitudes(Analyzed, max_nr_peaks);

Analyzed.max_nr_cycles = max_nr_peaks;
Analyzed.factor = factor;
Analyzed.goodwaves = goodwaves;
Analyzed.badwaves = badwaves;
Analyzed.nr_good_waves = goods;
Analyzed.nr_bad_waves = bads;

