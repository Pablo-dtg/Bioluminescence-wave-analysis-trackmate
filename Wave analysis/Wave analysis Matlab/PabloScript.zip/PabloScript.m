% Import Excel sheet from Pablo
% Import the Raw tab sheet
% Exclude the top row and the first column
% Import as 'Numeric Matrix' (in Output Type field)
% Change the name of the variable below 'OutputexportXXXXXXX'
% Then run PabloScript

CellData = createCellData(Outputexport2501062);
CycleData = getPabloData(CellData);
PabloData.peak_trough_dif = CycleData.peak_trough_dif;
PabloData.peak_trough_dif_single = CycleData.peak_trough_dif_single;
PabloData.AveragesPerCycle = CycleData.AveragesPerCycle;
%close all

