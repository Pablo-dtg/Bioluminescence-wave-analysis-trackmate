function PabloData = getPabloData(Analyzed)

max_nr_cycles = 15;
nr_cells = size(Analyzed.Smooth,2);
% Mean trace of all raw traces
% First all raw traces must be aligned
maxtime = max(max(Analyzed.TimeRaw));
mintime = min(min(Analyzed.TimeRaw));
rawsignals = NaN(maxtime+1-mintime, nr_cells);
rtime = [mintime:maxtime];
for i=1:nr_cells
    minidx = find(rtime(:)==min(Analyzed.TimeRaw(:,i)));
    maxidx = find(rtime(:)==max(Analyzed.TimeRaw(:,i))); %find(smoothtime(:)==max(Analyzed.TimeRaw(:,i)));
    if (minidx==1)
        rawsignals(1:maxidx, i)=rmmissing(Analyzed.Raw(:,i));
    else
        rawsignals(1:minidx-1,i) = NaN;
        rawsignals(minidx:maxidx,i) = Analyzed.Raw(1:maxidx-minidx+1,i);
    end
end
mean_trace = mean(rawsignals,2,'omitnan');
figure
plot(rtime, rawsignals);
hold on
plot(rtime, mean_trace, 'k', 'LineWidth', 2);
hold off

% Mean trace of all smoothed traces
% First all smoothed traces must be aligned
maxtime = max(max(Analyzed.Time));
mintime = min(min(Analyzed.Time));
smoothtime = [mintime:1/Analyzed.factor:maxtime];
for i=1:nr_cells
    minidx = find(smoothtime(:)==min(Analyzed.TimeRaw(:,i)));
    maxidx = size(Analyzed.Smooth,1); %find(smoothtime(:)==max(Analyzed.TimeRaw(:,i)));
    if (minidx==1)
        smoothsignals(:,i)=Analyzed.Smooth(:,i);
    else
        smoothsignals(1:minidx-1,i) = NaN;
        smoothsignals(minidx:maxidx,i) = Analyzed.Smooth(1:maxidx-minidx+1,i);
    end
end
mean_trace_s = mean(smoothsignals,2,'omitnan');

% Smooth mean trace
tim2 =[rtime(1):1/60:rtime(end)+1]';
[good_wave, mean_trace_smooth, norm, detrended, smoothfactor] = biolumSmoothData(rmmissing(mean_trace), Analyzed.factor, 1, tim2);
% w=ones(size(mean_trace),size(mean_trace));
% [mean_trace_smooth, smoothfactor]      = Biolum_smoother(mean_trace,1/Analyzed.factor,1,w);
if size(smoothtime,2)==size(smoothsignals,1)
    figure
    plot(smoothtime, smoothsignals);
    hold on
    plot(smoothtime, mean_trace_smooth, 'k', 'LineWidth', 2);
    hold off
    figure
    plot(smoothtime, mean_trace_s, 'LineWidth', 2);
    hold on
    plot(smoothtime, mean_trace_smooth, 'k', 'LineWidth', 2);
    hold off
else
    figure
    plot(smoothtime, mean_trace_smooth, 'k', 'LineWidth', 2);
end

PabloData.Mean_trace = mean_trace_smooth;

% Get all information for the mean trace (peaks, troughs etc...)
MeanAnalysis = analyzePeaksTroughs(mean_trace_smooth, smoothtime', Analyzed.factor, Analyzed.max_nr_cycles);
meanpeaks = MeanAnalysis.PeakTimes(MeanAnalysis.PeakTimes~=0);
meantroughs = MeanAnalysis.TroughTimes(MeanAnalysis.TroughTimes~=0);
meanhalfmaxup = MeanAnalysis.HalfmaxUpTimes(MeanAnalysis.HalfmaxUpTimes~=0);
if (meanpeaks(1)<meanhalfmaxup(1))
    meanpeaks = meanpeaks(2:end);
end

nr_cycles = size(meanhalfmaxup,2);
% Get peaktimes for all peaktimes of the mean trace
allpeakvals = NaN(nr_cycles,nr_cells);
alltroughvals = NaN(nr_cycles,nr_cells);
allphase = NaN(nr_cycles,nr_cells);
allperiod = NaN(nr_cycles,nr_cells);
allp2tampl = NaN(nr_cycles,nr_cells);
allt2pampl = NaN(nr_cycles,nr_cells);
cellpeaktimes = NaN(nr_cells, nr_cycles);
celltroughtimes = NaN(nr_cells, nr_cycles);
celltrough2peakdiff = NaN(nr_cells, nr_cycles);
cellpeak2troughdiff = NaN(nr_cells, nr_cycles);

count = 1;
periodcount = 1;
for i=1:nr_cycles
    mpmintime = meanhalfmaxup(i)-6;
    if mpmintime < 0
        mpmintime = 0;
    end
    mpmaxtime = meanhalfmaxup(i)+6;
    if mpmaxtime > maxtime
        mpmaxtime = maxtime;
    end
    for j=1:nr_cells
        phases = Analyzed.HalfmaxUpTimes(j,:);
        phases = phases(phases~=0);
        for k=1:size(phases,2)
            if (phases(k) > mpmintime && phases(k) < mpmaxtime)
                % Cell active in this period
                % Phase
                allphase(i,count) = phases(k);
                % Peak value
                if Analyzed.PeakTimes(j,k) < phases(k) % Peak before halfmaxup: take next peak
                    if Analyzed.PeakTimes(j,k+1) ~= 0 % Peak after halfmaxup is present
                        allpeakvals(i,count) = Analyzed.PeakVals(j,k+1);
                        cellpeaktimes(j,i) = Analyzed.PeakTimes(j,k+1);
                    end
                else
                    allpeakvals(i,count) = Analyzed.PeakVals(j,k);
                    cellpeaktimes(j,i) = Analyzed.PeakTimes(j,k);
                end
                % Trough value
                if Analyzed.TroughTimes(j,k) < phases(k) % Trough is present before halfmaxup
                    alltroughvals(i,count) = Analyzed.TroughVals(j,k);
                    celltroughtimes(j,i) = Analyzed.TroughTimes(j,k);
                end
                % Period
                if k~=size(phases,2) % X phases halfmax = X-1 periods
                    allperiod(i,periodcount) = Analyzed.PeriodHalfmax(j,k);
                    periodcount = periodcount+1;
                end
                % Peak-to-trough amplitude
                if Analyzed.PeakTimes(j,k) > phases(k)
                    if Analyzed.TroughTimes(j,k) > phases(k)
                        allp2tampl(i,count) = abs(Analyzed.PeakVals(j,k)-Analyzed.TroughVals(j,k));
                    elseif Analyzed.TroughTimes(j,k+1) > phases(k)
                        allp2tampl(i,count) = abs(Analyzed.PeakVals(j,k)-Analyzed.TroughVals(j,k+1));
                    end
                elseif Analyzed.PeakTimes(j,k+1) > phases(k)
                    if Analyzed.TroughTimes(j,k+1) > phases(k)
                        allp2tampl(i,count) = abs(Analyzed.PeakVals(j,k+1)-Analyzed.TroughVals(j,k+1));
                    end
                end
                % Trough-to-peak amplitude
                if Analyzed.TroughTimes(j,k) > phases(k)
                    if (k>1)
                        if Analyzed.TroughTimes(j,k-1) < phases(k)
                            if Analyzed.PeakTimes(j,k) > phases(k)
                                allt2pampl(i,count) = abs(Analyzed.PeakVals(j,k)-Analyzed.TroughVals(j,k-1));
                            end
                        end
                    end
                else
                    if Analyzed.PeakTimes(j,k) > phases(k)
                        allt2pampl(i,count) = abs(Analyzed.PeakVals(j,k)-Analyzed.TroughVals(j,k));
                    elseif Analyzed.PeakTimes(j,k+1) > phases(k)
                        allt2pampl(i,count) = abs(Analyzed.PeakVals(j,k+1)-Analyzed.TroughVals(j,k));
                    end
                end
                
                count = count+1;
            end
        end
    end
    count = 1;
    periodcount = 1;
end
allpeakvals = allpeakvals';
alltroughvals = alltroughvals';
allphase = allphase';
allperiod = allperiod';
allp2tampl = allp2tampl';
allt2pampl = allt2pampl';
mean_allpeakvals = mean(allpeakvals,'omitnan'); % Mean
mean_alltroughvals = mean(alltroughvals,'omitnan'); % Mean
mean_allphase = mean(allphase,'omitnan'); % Mean
mean_allperiod = mean(allperiod,'omitnan'); % Mean
mean_allp2tampl = mean(allp2tampl,'omitnan'); % Mean
mean_allt2pampl = mean(allt2pampl,'omitnan'); % Mean

PabloData.Peaks = allpeakvals;
PabloData.Troughs = alltroughvals;
PabloData.Phase = allphase;
PabloData.Period = allperiod;
PabloData.Peak2TroughAmplitude = allp2tampl;
PabloData.Trough2PeakAmplitude = allt2pampl;
PabloData.meanPeaks = mean_allpeakvals;
PabloData.meanTroughs = mean_alltroughvals;
PabloData.meanPhase = mean_allphase;
PabloData.meanPeriod = mean_allperiod;
PabloData.meanPeak2TroughDiff = mean_allp2tampl;
PabloData.meanTrough2PeakDiff = mean_allt2pampl;
mt2pampl = mean(mean_allt2pampl,'omitnan');
mt2pampl4 = mean(mean_allt2pampl(1:4),'omitnan');
t2pampl = [mean_allt2pampl 0 0 mt2pampl mt2pampl4];
mpeaks = mean(mean_allpeakvals, 'omitnan');
mpeaks4 = mean(mean_allpeakvals(1:4), 'omitnan');
peaks_l = [mean_allpeakvals 0 0 mpeaks mpeaks4];
mtroughs = mean(mean_alltroughvals, 'omitnan');
mtroughs4 = mean(mean_alltroughvals(1:4), 'omitnan');
troughs_l = [mean_alltroughvals 0 0 mtroughs mtroughs4];
mphase = mean(mean_allphase, 'omitnan');
mphase4 = mean(mean_allphase(1:4), 'omitnan');
phase_l = [mean_allphase 0 0 mphase mphase4];
mperiod = mean(mean_allperiod, 'omitnan');
mperiod4 = mean(mean_allperiod(1:4), 'omitnan');
period_l = [mean_allperiod 0 0 mperiod mperiod4];

AveragesPerCycle = [t2pampl; peaks_l; troughs_l; phase_l; period_l];
PabloData.AveragesPerCycle = AveragesPerCycle;

PabloData.PeakTimesPerCell = cellpeaktimes;
PabloData.TroughTimesPerCell = celltroughtimes;
% Determine trough-peak time differences
for i=1:nr_cells
    for j=1:size(celltroughtimes,2)
        if celltroughtimes(i,j)<cellpeaktimes(i,j)
            celltrough2peakdiff(i,j) = abs(celltroughtimes(i,j)-cellpeaktimes(i,j));
        elseif j<size(celltroughtimes,2)
            celltrough2peakdiff(i,j) = abs(celltroughtimes(i,j)-cellpeaktimes(i,j+1));
        end
    end
end
PabloData.Trough2PeakDiffSingle = celltrough2peakdiff;
mean_t2pdiff = mean(celltrough2peakdiff,1,'omitnan');
PabloData.CellsTrough2PeakDiff = mean_t2pdiff;

meantrough2peakdiff = [];
for i=1:size(meanpeaks,2)
    if meantroughs(i)<meanpeaks(i)
        meantrough2peakdiff(i) = abs(meantroughs(i)-meanpeaks(i));
    elseif i<size(meanpeaks,2)
        meantrough2peakdiff(i) = abs(meantroughs(i)-meanpeaks(i+1));
    end
end
PabloData.MeanTrough2PeakDiff = meantrough2peakdiff;

% Determine peak-trough time differences
for i=1:nr_cells
    for j=1:size(cellpeaktimes,2)
        if cellpeaktimes(i,j)<celltroughtimes(i,j)
            cellpeak2troughdiff(i,j) = abs(cellpeaktimes(i,j)-celltroughtimes(i,j));
        elseif j<size(cellpeaktimes,2)
            cellpeak2troughdiff(i,j) = abs(cellpeaktimes(i,j)-celltroughtimes(i,j+1));
        end
    end
end
PabloData.Peak2TroughDiffSingle = cellpeak2troughdiff;
mean_p2tdiff = mean(cellpeak2troughdiff,1,'omitnan');
PabloData.CellsPeak2TroughDiff = mean_p2tdiff;

meanpeak2troughdiff = [];
for i=1:size(meanpeaks,2)
    if meanpeaks(i)<meantroughs(i)
        meanpeak2troughdiff(i) = abs(meanpeaks(i)-meantroughs(i));
    elseif i<size(meantroughs,2)
        meanpeak2troughdiff(i) = abs(meanpeaks(i)-meantroughs(i+1));
    end
end
PabloData.MeanPeak2TroughDiff = meanpeak2troughdiff;

ct2pdif = mean(mean_t2pdiff, 'omitnan');
ct2pdif4 = mean(mean_t2pdiff(1:4), 'omitnan');
mtemp = [];
mtemp = mean_t2pdiff;
while(size(mtemp,2)<10)
    mtemp = [mtemp 0];
end
ct2pdif_l = [mtemp ct2pdif ct2pdif4];
cp2tdif = mean(mean_p2tdiff, 'omitnan');
cp2tdif4 = mean(mean_p2tdiff(1:4), 'omitnan');
mtemp = [];
mtemp = mean_p2tdiff;
while(size(mtemp,2)<10)
    mtemp = [mtemp 0];
end
cp2tdif_l = [mtemp cp2tdif cp2tdif4];

ptdifsingle = [ct2pdif_l' cp2tdif_l'];
PabloData.peak_trough_dif_single = ptdifsingle;

mt2pdif = mean(meantrough2peakdiff, 'omitnan');
mt2pdif4 = mean(meantrough2peakdiff(1:4), 'omitnan');
mtemp = [];
mtemp = meantrough2peakdiff;
while(size(mtemp,2)<10)
    mtemp = [mtemp 0];
end
mt2pdif_l = [mtemp mt2pdif mt2pdif4];
mp2tdif = mean(meanpeak2troughdiff, 'omitnan');
mp2tdif4 = mean(meanpeak2troughdiff(1:4), 'omitnan');
mtemp = [];
mtemp = meanpeak2troughdiff;
while(size(mtemp,2)<10)
    mtemp = [mtemp 0];
end
mp2tdif_l = [mtemp mp2tdif mp2tdif4];

ptdif = [mt2pdif_l' mp2tdif_l'];
PabloData.peak_trough_dif = ptdif;

% % Get peaktimes for all peaktimes of the mean trace
% allpeaks = NaN(size(meanpeaks,2),nr_cells);
% count = 1;
% for i=1:size(meanpeaks,2)
%     mpmintime = meanpeaks(i)-6;
%     if mpmintime < 0
%         mpmintime = 0;
%     end
%     mpmaxtime = meanpeaks(i)+6;
%     if mpmaxtime > maxtime
%         mpmaxtime = maxtime;
%     end
%     for j=1:nr_cells
%         peaktimes = Analyzed.PeakTimes(j,:);
%         peaktimes = peaktimes(peaktimes~=0);
%         for k=1:size(peaktimes,2)
%             if (peaktimes(k) > mpmintime && peaktimes(k) < mpmaxtime)
%                 allpeaks(i,count) = peaktimes(k);
%                 count = count+1;
%             end
%         end
%     end
%     count = 1;
% end
% allpeaks = allpeaks';
% mean_allpeaks = mean(allpeaks,'omitnan'); % Mean for allpeaks
