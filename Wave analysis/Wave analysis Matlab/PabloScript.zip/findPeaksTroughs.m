function [peaks_all, troughs_all, peak_phase_all, trough_phase_all] = findPeaksTroughs(tim, val)

% Time from 0 to 180 hours
% Time of first peak is between 20-30 hours
% Time of second peak is between 50-60 hours
% Time of third peak is between 75-85 hours
% Time of fourth peak is between 100-110 hours
% Time of fifth peak is between 125-140 hours
% Time of sixth peak is between 145-170 hours
% Time of first trough is before 20 hours
% Time of second trough is between 30-50 hours
% ...

tim = rmmissing(tim);
val = rmmissing(val);

peaks1=zeros(1,10);
troughs1=zeros(1,10);
peak_phase1=zeros(1,10);
trough_phase1=zeros(1,10);
peaks_all=zeros(1,10);
troughs_all=zeros(1,10);
peak_phase_all=zeros(1,10);
trough_phase_all=zeros(1,10);

mintime = tim(1);
maxtime = tim(end);

maxindex = size(val,1);

nr_cycles = round((maxtime-mintime)/24);

mess = sprintf('From %d to %d, %d cycles', mintime, maxtime, nr_cycles);
disp(mess);

if (val(2)-val(1) > 0)
    % Peak first
    disp('Peak first')
    peaknext = 1;
    rise=1;
else
    % Trough first
    disp('Trough first')
    peaknext = 0;
    rise=0;
end

peak_idx = 1;
trough_idx = 1;

% start = mintime;
% eind = mintime+15;

for i=1:maxindex-1
    if (val(i+1)>val(i) && rise==0)
        % Trough reached
        troughs_all(trough_idx) = val(i);
        trough_phase_all(trough_idx) = tim(i);
        trough_idx = trough_idx+1;
    elseif (val(i+1)<val(i) && rise==1)
        % Peak reached
        peaks_all(peak_idx) = val(i);
        peak_phase_all(peak_idx) = tim(i);
        peak_idx = peak_idx+1;
    end
    if (val(i+1)>val(i))
        rise = 1;
    else
        rise = 0;
    end
end
        
        
%         
% 
% 
% for i=1:((nr_cycles/2)-1)
%     start_idx = find((tim>(start-0.001))&(tim<(start+0.001)));
%     end_idx = find((tim>(eind-0.001))&(tim<(eind+0.001)));
%     if isempty(end_idx)
%         end_idx = find(tim==maxtime);
%     end
%     if peaknext
%         index = find(val(start_idx:end_idx)==max(val(start_idx:end_idx)))+start_idx;
%         if (index>maxindex)
%             index=maxindex;
%         end
%         if (size(index,1)>1)
%             index = index(1);
%         end
%         peaks_all(peak_idx) = val(index);
%         peak_phase_all(peak_idx) = tim(index);
%         peak_idx = peak_idx+1;
%         if (tim(index)>20 && tim(index)<30)
%             peaks1(1) = val(index);
%             peak_phase1(1) = tim(index);
%         elseif (tim(index)>50 && tim(index)<60)
%             peaks1(2) = val(index);
%             peak_phase1(2) = tim(index);
%         elseif (tim(index)>75 && tim(index)<85)
%             peaks1(3) = val(index);
%             peak_phase1(3) = tim(index);
%         elseif (tim(index)>100 && tim(index)<110)
%             peaks1(4) = val(index);
%             peak_phase1(4) = tim(index);
%         elseif (tim(index)>125 && tim(index)<140)
%             peaks1(5) = val(index);
%             peak_phase1(5) = tim(index);
%         elseif (tim(index)>145 && tim(index)<170)
%             peaks1(6) = val(index);
%             peak_phase1(6) = tim(index);
%         end
%         peaknext = 0;
%     else
%         index = find(val(start_idx:end_idx)==min(val(start_idx:end_idx)))+start_idx;
%         if (index>maxindex)
%             index=maxindex;
%         end
%         if (size(index,1)>1)
%             index = index(1);
%         end
%         troughs_all(trough_idx) = val(index);
%         trough_phase_all(trough_idx) = tim(index);
%         trough_idx = trough_idx+1;
%         if (tim(index)<20)
%             troughs1(1) = val(index);
%             trough_phase1(1) = tim(index);
%         elseif (tim(index)>30 && tim(index)<50)
%             troughs1(2) = val(index);
%             trough_phase1(2) = tim(index);
%         elseif (tim(index)>60 && tim(index)<75)
%             troughs1(3) = val(index);
%             trough_phase1(3) = tim(index);
%         elseif (tim(index)>85 && tim(index)<100)
%             troughs1(4) = val(index);
%             trough_phase1(4) = tim(index);
%         elseif (tim(index)>110 && tim(index)<125)
%             troughs1(5) = val(index);
%             trough_phase1(5) = tim(index);
%         elseif (tim(index)>120 && tim(index)<150)
%             troughs1(6) = val(index);
%             trough_phase1(6) = tim(index);
%         elseif (tim(index)>160)
%             troughs1(7) = val(index);
%             trough_phase1(7) = tim(index);
%         end
%         peaknext = 1;
%     end
%     start = tim(index);
%     eind = start+15;
% end
% 
%     
% end

