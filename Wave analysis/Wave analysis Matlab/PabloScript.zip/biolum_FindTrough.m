function bin = biolum_FindTrough(Smooth, bin_nr, down)
% Find trough bin
% When 'down' = 1, trough is in a later bin
% When 'down' = 0, trough is in an earlier bin
bin = bin_nr;
while (bin > 0 && bin < size(Smooth,1) && ((down && Smooth(bin+1) <= Smooth(bin)) || (~down && Smooth(bin+1) >= Smooth(bin))))
    if down == 1
        bin = bin + 1;
    else
        bin = bin - 1;
    end
end
if bin >= size(Smooth,1) || bin < 0
    bin = 0;
end
        
        