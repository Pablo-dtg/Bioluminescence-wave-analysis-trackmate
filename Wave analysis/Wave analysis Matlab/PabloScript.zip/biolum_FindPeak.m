function bin = biolum_FindPeak(Smooth, bin_nr, up)
% Find peak bin
% When 'up' = 1, peak is in a later bin
% When 'up' = 0, peak is in an earlier bin
bin = bin_nr;
while (bin > 0 && bin < size(Smooth,1) && ((up && Smooth(bin+1) >= Smooth(bin)) || (~up && Smooth(bin+1) <= Smooth(bin))))
    if up == 1
        bin=bin+1;
    else
        bin=bin-1;
    end
end
if bin >= size(Smooth,1) || bin < 0
    bin = 0;
end
        
        