function [z, smoothfactor] = Biolum_smoother(data,dt,freqlow,w)

% Adjust lowest frequency to smooth
smooth.lowfreq  = (freqlow/pi);

% Get variability of the data
smooth.df       = mean(std(data));
%smooth.dt       = time(2) - time(1);

% Get smoothfactor based on variablility
smooth.fac      = (smooth.lowfreq / dt)^2;
smooth.frq      = (smooth.df * smooth.lowfreq);
smooth.lambda   = (smooth.fac / dt) * smooth.frq;

smooth.rescale  = min(min(data));
data            = log(1 + (data - smooth.rescale));
% If the data is interpolated into more bins, weights w are given
% Then the result will be a smoothed signal with more time points
% as the riginal data.
smoothfactor = smooth.lambda/pi;
if nargin < 4
    z               = smoothmatsimpleHT(data',smoothfactor,2)';
else
    z               = smoothmatsimpleHT(data',smoothfactor,2,w)';
end
z               = exp(z) - 1 + smooth.rescale;
%disp(smooth);

