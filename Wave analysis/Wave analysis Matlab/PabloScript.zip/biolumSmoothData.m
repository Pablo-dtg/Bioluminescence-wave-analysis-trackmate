function [good_wave, smooth, norm, detrended, smoothfactor] = biolumSmoothData(dat, factor, t, tim)

% First interpolate the raw data using the algorithm of Paul Eilers
% described in 'A Perfect Smoother', 2003, Anal Chem 75, 3631-3636.
N = size(dat,1);
M = N*factor;
x = 0:factor:factor*N-1;
xi = 0:M-1;
% The data is organized in the desired timeframe and a series of weights
% is created with only ones at the time points of the data.
dati(1:M,1:size(dat,2))=0;
w=zeros(M);
for i=1:N-1
    dati(x(i)+1,:)=dat(i,:);
    w(x(i)+1)=1;
end

% Then smooth the resampled output
dt=t/(factor);
[smooth, smoothfactor]      = Biolum_smoother(dati,dt,1,w);
good_wave = Check_Wave_Signal(smooth);

% Then normalize and detrend the data
% Use 'detrend' method from TSA toolkit, using fourth order polinomial
tim=tim(1:(end-1)); % Make time vector as long as data vectors
[detrended, norm]=detrend(tim',smooth,4);




% Henk Tjebbe's old method:
% %Use penalized least squares to get trend line
% Trends1     = Biolum_smoother(dati,dt,24,w);
% % Remove Trend, data zero on average,
% %  amplitude is similar in + and -
% Res         = dati - Trends1;
% %Fit regression on absolute detrended data to get amplitude trend
% Trends2     = Biolum_smoother(abs(Res),dt,10,w);
% % Divide by amplitude trend
% Norm        = Res ./ Trends2;
% % Rescale to average amplitude level
% Scaled1     = Norm .* repmat(mean(Trends2,1),size(dati,1),1);
% % replace previous baseline
% Scaled2     = Scaled1 + Trends1;
% % Remove trend from this
% Trends3     = Biolum_smoother(Scaled2,dt,24,w);
% Detrended   = (Scaled2 - Trends3) + repmat(mean(Trends3,1),size(dati,1),1);
% norm        = Biolum_smoother(Norm,dt,1,w);
% detrended   = Biolum_smoother(Detrended,dt,1,w);


