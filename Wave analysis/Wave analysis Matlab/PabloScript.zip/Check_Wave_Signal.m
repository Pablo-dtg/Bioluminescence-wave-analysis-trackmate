function good_wave = Check_Wave_Signal(Smoothed_Waveform)
% remove pixels that do not show rhythmic expression
% Img should be smoothed for ideal results
% Only positive pixels from map are checked


% parameters
  % peak detection
%   Range             = (Settings.Range*(60/Settings.Image_Interval))*Settings.Image_Interval;
  Min_Peak_Distance = 12;

  % good/bad peak
  Minimal_Nr_peaks      = 3;
  Period_Range          = [20 28]; % Default [20 28];
  Minimal_Nr_Good_Peaks = 3;
  ImageInterval = 60;

% Retrieve subscripts of positive pixels
  good_wave = 1;

% Peak identification parameters
    MinDistance = Min_Peak_Distance*ImageInterval;  % distance between peaks
    MINProm     = std(Smoothed_Waveform)*0.1; % height of peak (default =0.1)
    %MAXWidth    = 18; 'MaxPeakWidth',MAXWidth,


% Get peaks and Peak info
%     [pks,  locsP, w, p] = findpeaks(Smoothed_Waveform(Range(1):Range(2)),'MinPeakProminence',MINProm, 'MinPeakDistance',MinDistance); % find peaks and locations
    [pks,  locsP, w, p] = findpeaks(Smoothed_Waveform,'MinPeakProminence',MINProm, 'MinPeakDistance',MinDistance); % find peaks and locations
    Peak_Dist   = diff(locsP);  % distance between peaks
    Nr_Peaks    = length(pks);  % Nr. Peaks

% remove linear trend in wave
%     Detrended_Wave = detrend(Smoothed_Waveform(Range(1):Range(2)), 'linear');   
    Detrended_Wave = detrend(Smoothed_Waveform, 'linear');   
    [pks_Detr   Plocs_Detr] = findpeaks( Detrended_Wave,'MinPeakProminence',MINProm,'MinPeakDistance',MinDistance);
    [Trghs_Detr Tlocs_Detr] = findpeaks(-Detrended_Wave,'MinPeakProminence',MINProm,'MinPeakDistance',MinDistance);

         
    
    %findpeaks(Smoothed_Waveform,'MinPeakProminence',MINProm, 'MinPeakDistance',MinDistance,'Annotate','extents')
   
       
 
    % filtering of good waves
%     if Nr_Peaks>Minimal_Nr_peaks  && mean(Peak_Dist) < Period_Range(2)*ImageInterval && mean(Peak_Dist) > Period_Range(1)*ImageInterval
    if Nr_Peaks>Minimal_Nr_peaks  && max(Peak_Dist) < Period_Range(2)*ImageInterval && min(Peak_Dist) > Period_Range(1)*ImageInterval
        good_wave = 1;
        %        if any(Detrended_Wave(Tlocs_Detr(Tlocs_Detr>Plocs_Detr(1))) > 0) || any(pks_Detr(1:end<(Minimal_Nr_Good_Peaks+1)) < 0)
        %
        %            if Settings.Amp_Modification==0
        %               bads(end+1) = i;
        %           else
        %             high_trough(end+1)=i;
        %            end
        %
        % %             x = [1:72]';
        % %             y = Smoothed_Waveform(1:72);
        % %
        % %             p = polyfit(x,y,15);
        % %             x1 = x;
        % %             y1 = polyval(p,x1);
        % %
        % %             figure
        % %             plot(x,y, 'LineWidth',2)
        % %             hold on
        % %             plot(x1,y1)
        % %             hold off
        % %
        % %
        % %             findpeaks(Smoothed_Waveform,'MinPeakProminence',MINProm, 'MinPeakDistance',MinDistance,'Annotate','extents')
        % %             title(['bad wave: object ' num2str(i)])
        % %             waitforbuttonpress;
        %        else
        % %              findpeaks(Smoothed_Waveform,'MinPeakProminence',MINProm, 'MinPeakDistance',MinDistance,'Annotate','extents')
        % %              title(['Good wave: object ' num2str(i)])
        % %              waitforbuttonpress;
        %        end
        %
    else
        good_wave = 0;
        %      bads(end+1) = i;
        
        %             findpeaks(Smoothed_Waveform,'MinPeakProminence',MINProm, 'MinPeakDistance',MinDistance,'Annotate','extents')
        %             title(['bad wave: object ' num2str(i)])
        %             waitforbuttonpress;
    end
end

