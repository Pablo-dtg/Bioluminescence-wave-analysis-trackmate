function [HalfmaxUp, HalfmaxDown] = biolum_FindHalfmax(Analyzed, Signal,i,max_nr_peaks)

up = 1;
down = 0;

HalfmaxUp = [];
HalfmaxDown = [];
for j = 1:(size(Analyzed.Peaks, 2)-1)
    % Peaks and Troughs are of constant length and have '0' if no value
    % was found (similar to NaN). If one of the two is '0', then no
    % halfmax value can be found.
    if Analyzed.Peaks(i,j) > 0 & Analyzed.Troughs(i,j) > 0
        if Analyzed.Peaks(i, j) > Analyzed.Troughs(i, j)
            % For this timetrace, the trough is first, followed by the peak
            % Get value of halfmax between first trough and peak
            half_val = ((Signal(Analyzed.Peaks(i, j)) - Signal(Analyzed.Troughs(i, j)))/2)+Signal(Analyzed.Troughs(i, j));
            % Get bin that corresponds closest to this halfmax value
            bin = biolum_FindBin(Signal, Analyzed.Troughs(i,j), half_val, up);
            % Add bin to HalfmaxUp
            HalfmaxUp = [HalfmaxUp, bin];
            if Analyzed.Troughs(i, j+1) > 0
                % Get value of halfmax of peak and second trough
                half_val = ((Signal(Analyzed.Peaks(i, j)) - Signal(Analyzed.Troughs(i, j+1)))/2)+Signal(Analyzed.Troughs(i, j+1));
                % Find bin and add it to HalfmaxDown
                HalfmaxDown = [HalfmaxDown, biolum_FindBin(Signal, Analyzed.Peaks(i,j), half_val, down)];
            end
        else
            % For this timetrace the peak is first, followed by the trough
            % Get value of halfmax between first peak and trough
            half_val = ((Signal(Analyzed.Peaks(i, j)) - Signal(Analyzed.Troughs(i, j)))/2)+Signal(Analyzed.Troughs(i, j));
            % Get closest bin and add it to HalfmaxDown
            HalfmaxDown = [HalfmaxDown, biolum_FindBin(Signal, Analyzed.Peaks(i,j), half_val, down)];
            if Analyzed.Peaks(i, j+1) > 0
                % Get value of halfmax between trough and second peak
                half_val = ((Signal(Analyzed.Peaks(i, j+1)) - Signal(Analyzed.Troughs(i, j)))/2)+Signal(Analyzed.Troughs(i, j));
                % Get closest bin and add it to HalfmaxUp
                HalfmaxUp = [HalfmaxUp, biolum_FindBin(Signal, Analyzed.Troughs(i,j), half_val, up)];
            end
        end
    end
end
HalfmaxUp = HalfmaxUp';
HalfmaxDown = HalfmaxDown';
% HalfmaxUp and HalfmaxDown need to have a constant length, so they are
% filled with '0'.
% if size(HalfmaxUp,2)>max_nr_peaks
%     HalfmaxUp = HalfmaxUp(1:max_nr_peaks);
% else
%     while(size(HalfmaxUp,2)<max_nr_peaks)
%         HalfmaxUp = [HalfmaxUp, 0];
%     end
% end
% if size(HalfmaxDown,2)>max_nr_peaks
%     HalfmaxDown = HalfmaxDown(1:max_nr_peaks);
% else
%     while(size(HalfmaxDown,2)<max_nr_peaks)
%         HalfmaxDown = [HalfmaxDown, 0];
%     end
% end
